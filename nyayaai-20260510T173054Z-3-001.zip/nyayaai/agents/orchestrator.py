"""Builds a ClaudeSDKClient with the main orchestrator + 5 specialist subagents."""
from claude_agent_sdk import (
    ClaudeAgentOptions,
    ClaudeSDKClient,
    AgentDefinition,
)
from . import prompts
from .tools import rag_server

LEGAL_TOOL = "mcp__rag__retrieve_legal_docs"
COMP_TOOL = "mcp__rag__retrieve_compliance_rules"

SUBAGENTS = {
    "legal-research": AgentDefinition(
        description="Find statutes, case law, and legal templates relevant to a question.",
        prompt=prompts.LEGAL_RESEARCH,
        tools=[LEGAL_TOOL],
        model="sonnet",
    ),
    "case-strategy": AgentDefinition(
        description="Recommend strategic approaches given facts and research.",
        prompt=prompts.CASE_STRATEGY,
        tools=[],
        model="sonnet",
    ),
    "legal-drafting": AgentDefinition(
        description="Draft contracts, NDAs, demand letters, motions, and clauses.",
        prompt=prompts.LEGAL_DRAFTING,
        tools=[LEGAL_TOOL],
        model="sonnet",
    ),
    "compliance-review": AgentDefinition(
        description="Review situations or clauses against GDPR, HIPAA, SOC2, CCPA, PCI.",
        prompt=prompts.COMPLIANCE_REVIEW,
        tools=[COMP_TOOL],
        model="sonnet",
    ),
    "client-intake": AgentDefinition(
        description="Friendly plain-English fact gathering and area-of-law identification.",
        prompt=prompts.CLIENT_INTAKE,
        tools=[],
        model="sonnet",
    ),
}


def build_options() -> ClaudeAgentOptions:
    return ClaudeAgentOptions(
        system_prompt=prompts.MAIN_ORCHESTRATOR,
        mcp_servers={"rag": rag_server},
        agents=SUBAGENTS,
        allowed_tools=["Task", LEGAL_TOOL, COMP_TOOL],
        permission_mode="bypassPermissions",
        model="claude-sonnet-4-6",
    )


def build_client() -> ClaudeSDKClient:
    return ClaudeSDKClient(options=build_options())
