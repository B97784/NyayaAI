"""Fake RAG tools — keyword scan over canned JSON corpora."""
import json
from pathlib import Path
from claude_agent_sdk import tool, create_sdk_mcp_server

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
_LEGAL = json.loads((DATA_DIR / "legal_docs.json").read_text())
_COMPLIANCE = json.loads((DATA_DIR / "compliances.json").read_text())


def _search(corpus, query, k=3):
    q = query.lower()
    terms = [t for t in q.replace(",", " ").split() if len(t) > 2]
    scored = []
    for doc in corpus:
        hay = (doc.get("text", "") + " " + doc.get("topic", "") + " " + doc.get("title", "") + " " + doc.get("rule", "")).lower()
        score = sum(1 for t in terms if t in hay)
        if score:
            scored.append((score, doc))
    scored.sort(key=lambda x: -x[0])
    return [d for _, d in scored[:k]]


@tool(
    "retrieve_legal_docs",
    "Retrieve legal documents (statutes, case law, templates) relevant to a query.",
    {"query": str},
)
async def retrieve_legal_docs(args):
    hits = _search(_LEGAL, args["query"])
    if not hits:
        return {"content": [{"type": "text", "text": "No matching legal documents found."}]}
    return {"content": [{"type": "text", "text": json.dumps(hits, indent=2)}]}


@tool(
    "retrieve_compliance_rules",
    "Retrieve compliance rules (GDPR, HIPAA, SOC2, CCPA, PCI) relevant to a query.",
    {"query": str},
)
async def retrieve_compliance_rules(args):
    hits = _search(_COMPLIANCE, args["query"])
    if not hits:
        return {"content": [{"type": "text", "text": "No matching compliance rules found."}]}
    return {"content": [{"type": "text", "text": json.dumps(hits, indent=2)}]}


rag_server = create_sdk_mcp_server(
    name="rag",
    version="1.0.0",
    tools=[retrieve_legal_docs, retrieve_compliance_rules],
)
