"""Run eval cases against the orchestrator. Reports which subagents fired and which tools were called.

Usage: python -m evals.run_evals
"""
import asyncio
import json
import os
import sys
from pathlib import Path

# allow running as `python evals/run_evals.py`
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv
from claude_agent_sdk import AssistantMessage, ToolUseBlock, ResultMessage
from agents.orchestrator import build_client

load_dotenv()
CASES_FILE = Path(__file__).resolve().parent / "cases.jsonl"


async def run_case(case):
    invoked_agents = []
    tools_called = []
    duration_ms = None
    cost_usd = None
    async with build_client() as client:
        await client.query(case["prompt"])
        async for msg in client.receive_response():
            if isinstance(msg, AssistantMessage):
                for block in msg.content:
                    if isinstance(block, ToolUseBlock):
                        if block.name == "Task":
                            sub = block.input.get("subagent_type") if isinstance(block.input, dict) else None
                            if sub:
                                invoked_agents.append(sub)
                        else:
                            tools_called.append(block.name.replace("mcp__rag__", ""))
            elif isinstance(msg, ResultMessage):
                duration_ms = getattr(msg, "duration_ms", None)
                cost_usd = getattr(msg, "total_cost_usd", None)

    expected_agent = case["expected_agent"]
    expected_tool = case.get("expected_tool")
    agent_ok = expected_agent in invoked_agents
    tool_ok = (expected_tool is None) or (expected_tool in tools_called)
    return {
        "id": case["id"],
        "prompt": case["prompt"][:60],
        "expected_agent": expected_agent,
        "agents": invoked_agents,
        "tools": tools_called,
        "agent_ok": agent_ok,
        "tool_ok": tool_ok,
        "duration_ms": duration_ms,
        "cost_usd": cost_usd,
    }


async def main():
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("ANTHROPIC_API_KEY missing", file=sys.stderr)
        sys.exit(1)
    cases = [json.loads(line) for line in CASES_FILE.read_text().splitlines() if line.strip()]
    print(f"Running {len(cases)} cases...\n")
    results = []
    for c in cases:
        print(f"[{c['id']}] {c['prompt'][:70]}")
        try:
            r = await run_case(c)
        except Exception as e:
            r = {"id": c["id"], "error": str(e), "agent_ok": False, "tool_ok": False}
        results.append(r)
        ok = "✅" if r.get("agent_ok") and r.get("tool_ok") else "❌"
        print(f"  {ok} agents={r.get('agents')} tools={r.get('tools')}\n")

    print("\n## Summary\n")
    print("| ID | Expected Agent | Got | Tool OK | Time | Cost |")
    print("|---|---|---|---|---|---|")
    for r in results:
        print(f"| {r['id']} | {r.get('expected_agent','-')} | {','.join(r.get('agents',[])) or '-'} | "
              f"{'✅' if r.get('tool_ok') else '❌'} | "
              f"{(r.get('duration_ms') or 0)/1000:.1f}s | "
              f"${r.get('cost_usd') or 0:.4f} |")
    passed = sum(1 for r in results if r.get("agent_ok") and r.get("tool_ok"))
    print(f"\n**{passed}/{len(results)} passed**")


if __name__ == "__main__":
    asyncio.run(main())
