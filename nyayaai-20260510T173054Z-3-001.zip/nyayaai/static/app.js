const log = document.getElementById("log");
const form = document.getElementById("f");
const q = document.getElementById("q");
const send = document.getElementById("send");
const status = document.getElementById("status");
const agentList = document.getElementById("agent-list");
const suggestions = document.getElementById("suggestions");
const chatList = document.getElementById("chat-list");
const newChatBtn = document.getElementById("new-chat-btn");
const userEmail = document.getElementById("user-email");
const userAvatar = document.getElementById("user-avatar");
const logoutBtn = document.getElementById("logout-btn");
const chatTitle = document.getElementById("chat-title");
const toastHost = document.getElementById("toast-host");

const AGENT_LABELS = {
  "client-intake": "Client Intake",
  "legal-research": "Legal Research",
  "case-strategy": "Case Strategy",
  "legal-drafting": "Legal Drafting",
  "compliance-review": "Compliance Review",
};
const AGENT_ICONS = {
  "client-intake": "💬",
  "legal-research": "🔎",
  "case-strategy": "🎯",
  "legal-drafting": "✍️",
  "compliance-review": "🛡️",
};
const TOOL_LABELS = {
  "retrieve_legal_docs": "Searching legal corpus",
  "retrieve_compliance_rules": "Searching compliance corpus",
};

let currentChatId = null;
let lastUserMessage = null;

if (window.marked) {
  marked.setOptions({ breaks: true, gfm: true });
}

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function renderMd(text) {
  if (!window.marked || !window.DOMPurify) {
    return text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\n/g,"<br>");
  }
  const html = marked.parse(text || "");
  return DOMPurify.sanitize(html, { USE_PROFILES: { html: true } });
}

function toast(text, kind = "ok") {
  const t = el("div", "toast " + kind, text);
  toastHost.appendChild(t);
  requestAnimationFrame(() => t.classList.add("show"));
  setTimeout(() => {
    t.classList.remove("show");
    setTimeout(() => t.remove(), 250);
  }, 2200);
}

function setActiveAgents(active) {
  agentList.querySelectorAll("li").forEach(li => {
    li.classList.toggle("active", active.has(li.dataset.agent));
  });
}

function clearLog() { log.innerHTML = ""; }

function showEmpty() {
  clearLog();
  const empty = el("div", "empty-state");
  empty.innerHTML = `<div class="seal">⚖</div><h3>How can the bench assist you today?</h3><p>Ask a question, request a draft, or describe a matter. The orchestrator will route it to the right specialist.</p>`;
  log.appendChild(empty);
}

function clearEmpty() {
  const e = log.querySelector(".empty-state");
  if (e) e.remove();
}

function appendUser(text) {
  clearEmpty();
  const wrap = el("div", "msg user");
  const bubble = el("div", "bubble");
  bubble.innerHTML = renderMd(text);
  wrap.appendChild(bubble);
  log.appendChild(wrap);
  scrollToBottom();
}

function newAssistantMsg() {
  const wrap = el("div", "msg assistant");

  const flow = el("div", "flow");
  const flowHead = el("div", "flow-head");
  flowHead.innerHTML = `<span class="flow-icon">⚖</span><span class="flow-title">Orchestrator working</span><span class="flow-spinner"></span>`;
  const flowSteps = el("ul", "flow-steps");
  flow.append(flowHead, flowSteps);

  const text = el("div", "text");
  const actions = el("div", "actions");
  actions.style.display = "none";
  const meta = el("div", "meta");
  meta.style.display = "none";

  wrap.append(flow, text, actions, meta);
  log.appendChild(wrap);
  return { wrap, flow, flowHead, flowSteps, text, actions, meta };
}

function addFlowStep(slot, kind, label, status = "active") {
  const li = el("li", "flow-step " + status);
  li.dataset.kind = kind;
  li.dataset.label = label;
  const icon = el("span", "flow-step-icon");
  if (status === "active") icon.innerHTML = `<span class="mini-spinner"></span>`;
  else icon.textContent = "✓";
  li.append(icon, el("span", "flow-step-label", label));
  slot.flowSteps.appendChild(li);
  return li;
}

function completeFlowStep(slot, kind, label) {
  const li = [...slot.flowSteps.querySelectorAll(".flow-step")]
    .find(x => x.dataset.kind === kind && x.dataset.label === label && x.classList.contains("active"));
  if (li) {
    li.classList.remove("active");
    li.classList.add("done");
    li.querySelector(".flow-step-icon").innerHTML = "✓";
  }
}

function completeAllFlow(slot) {
  slot.flowSteps.querySelectorAll(".flow-step.active").forEach(li => {
    li.classList.remove("active");
    li.classList.add("done");
    li.querySelector(".flow-step-icon").innerHTML = "✓";
  });
  slot.flowHead.querySelector(".flow-spinner")?.remove();
  slot.flowHead.querySelector(".flow-title").textContent = "Bench complete";
  slot.flow.classList.add("collapsed");
}

function attachActions(slot, content) {
  slot.actions.style.display = "flex";
  slot.actions.innerHTML = "";

  const copy = el("button", "act-btn", "");
  copy.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg> Copy`;
  copy.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(content);
      toast("Copied to clipboard");
    } catch { toast("Copy failed", "err"); }
  });

  const regen = el("button", "act-btn", "");
  regen.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg> Regenerate`;
  regen.addEventListener("click", () => {
    if (!lastUserMessage) return;
    ask(lastUserMessage);
  });

  slot.actions.append(copy, regen);
}

function parseSSE(buf) {
  const events = [];
  const chunks = buf.split("\n\n");
  for (let i = 0; i < chunks.length - 1; i++) {
    const lines = chunks[i].split("\n");
    let event = "message", data = "";
    for (const line of lines) {
      if (line.startsWith("event: ")) event = line.slice(7);
      else if (line.startsWith("data: ")) data += line.slice(6);
    }
    if (data) {
      try { events.push({ event, data: JSON.parse(data) }); } catch {}
    }
  }
  return { events, rest: chunks[chunks.length - 1] };
}

function nearBottom() {
  return log.scrollHeight - log.scrollTop - log.clientHeight < 80;
}
let stickToBottom = true;
log.addEventListener("scroll", () => { stickToBottom = nearBottom(); });
function scrollToBottom() { if (stickToBottom) log.scrollTop = log.scrollHeight; }

// ---------- Auth bootstrap ----------
async function bootstrap() {
  const r = await fetch("/api/auth/me");
  if (!r.ok) { location.href = "/login"; return; }
  const u = await r.json();
  userEmail.textContent = u.email;
  userAvatar.textContent = (u.email[0] || "?").toUpperCase();
  await refreshChatList();
}

logoutBtn.addEventListener("click", async () => {
  await fetch("/api/auth/logout", { method: "POST" });
  location.href = "/login";
});

// ---------- Chat list ----------
async function refreshChatList() {
  const r = await fetch("/api/chats");
  if (!r.ok) return;
  const { chats } = await r.json();
  chatList.innerHTML = "";
  if (chats.length === 0) {
    chatList.appendChild(el("li", "empty-chats", "No briefs yet"));
    return;
  }
  for (const c of chats) {
    const li = el("li", "chat-item");
    if (c.id === currentChatId) li.classList.add("active");
    li.dataset.id = c.id;
    li.append(
      el("span", "chat-title-text", c.title),
      (() => { const b = el("button", "del-btn", "×"); b.title = "Delete"; b.dataset.del = c.id; return b; })(),
    );
    chatList.appendChild(li);
  }
}

chatList.addEventListener("click", async (e) => {
  const del = e.target.closest("[data-del]");
  if (del) {
    e.stopPropagation();
    const id = +del.dataset.del;
    if (!confirm("Delete this brief?")) return;
    const r = await fetch(`/api/chats/${id}`, { method: "DELETE" });
    if (r.ok) toast("Brief deleted");
    if (id === currentChatId) startNewChat();
    refreshChatList();
    return;
  }
  const item = e.target.closest(".chat-item");
  if (!item) return;
  loadChat(+item.dataset.id);
});

async function loadChat(id) {
  const r = await fetch(`/api/chats/${id}`);
  if (!r.ok) return;
  const { title, messages } = await r.json();
  currentChatId = id;
  chatTitle.textContent = title;
  clearLog();
  if (messages.length === 0) showEmpty();
  let lastAssistant = null;
  for (const m of messages) {
    if (m.role === "user") {
      lastUserMessage = m.content;
      const wrap = el("div", "msg user");
      const bubble = el("div", "bubble");
      bubble.innerHTML = renderMd(m.content);
      wrap.appendChild(bubble);
      log.appendChild(wrap);
    } else {
      const slot = newAssistantMsg();
      // build flow steps from saved agents
      if (m.agents) {
        for (const a of m.agents.split(",")) {
          addFlowStep(slot, "agent", AGENT_LABELS[a] || a, "done");
        }
      }
      completeAllFlow(slot);
      slot.text.innerHTML = renderMd(m.content);
      attachActions(slot, m.content);
      if (m.cost_usd != null) {
        slot.meta.style.display = "flex";
        slot.meta.append(
          el("span", null, `⏱ ${(m.duration_ms/1000).toFixed(1)}s`),
          el("span", null, `💰 $${m.cost_usd.toFixed(4)}`),
        );
      }
      lastAssistant = slot;
    }
  }
  log.scrollTop = log.scrollHeight;
  refreshChatList();
}

function startNewChat() {
  currentChatId = null;
  chatTitle.textContent = "Indian Legal Assistant";
  showEmpty();
  refreshChatList();
  q.focus();
}

newChatBtn.addEventListener("click", startNewChat);

// ---------- Ask ----------
async function ask(message) {
  appendUser(message);
  lastUserMessage = message;
  const slot = newAssistantMsg();
  send.disabled = true;
  status.classList.add("busy");
  status.lastChild.textContent = " working";

  const seenAgents = new Set();
  let raw = "";

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, chat_id: currentChatId }),
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const { events, rest } = parseSSE(buf);
      buf = rest;
      for (const { event, data } of events) {
        if (event === "chat") {
          const isNew = currentChatId === null;
          currentChatId = data.chat_id;
          if (isNew) refreshChatList();
        } else if (event === "text") {
          // mark all in-progress steps as done — answer is being written
          slot.flowSteps.querySelectorAll(".flow-step.active").forEach(li => {
            li.classList.remove("active");
            li.classList.add("done");
            li.querySelector(".flow-step-icon").innerHTML = "✓";
          });
          raw += data.text;
          slot.text.innerHTML = renderMd(raw);
        } else if (event === "tool") {
          if (data.name === "Task" || data.name === "Agent") {
            const sub = data.input?.subagent_type;
            if (sub && !seenAgents.has(sub)) {
              seenAgents.add(sub);
              setActiveAgents(seenAgents);
              const label = `${AGENT_ICONS[sub] || "🧑‍⚖️"} ${AGENT_LABELS[sub] || sub}`;
              addFlowStep(slot, "agent", label);
            }
          } else {
            const short = data.name.replace("mcp__rag__", "");
            const label = TOOL_LABELS[short] || short;
            addFlowStep(slot, "tool", "📚 " + label);
          }
        } else if (event === "done") {
          completeAllFlow(slot);
          if (data.cost_usd != null) {
            slot.meta.style.display = "flex";
            slot.meta.append(
              el("span", null, `⏱ ${(data.duration_ms/1000).toFixed(1)}s`),
              el("span", null, `💰 $${data.cost_usd.toFixed(4)}`),
            );
          }
        } else if (event === "error") {
          slot.wrap.appendChild(el("div", "err", "Error: " + data.message));
        }
        scrollToBottom();
      }
    }
    if (raw) attachActions(slot, raw);
    refreshChatList();
  } catch (err) {
    slot.wrap.appendChild(el("div", "err", "Network error: " + err.message));
  } finally {
    send.disabled = false;
    status.classList.remove("busy");
    status.lastChild.textContent = " ready";
    setTimeout(() => setActiveAgents(new Set()), 1500);
    q.focus();
  }
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = q.value.trim();
  if (!text) return;
  q.value = "";
  q.style.height = "auto";
  ask(text);
});

q.addEventListener("input", () => {
  q.style.height = "auto";
  q.style.height = Math.min(q.scrollHeight, 200) + "px";
});

q.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    form.requestSubmit();
  }
});

suggestions.addEventListener("click", (e) => {
  const chip = e.target.closest(".chip");
  if (!chip) return;
  q.value = chip.dataset.prompt;
  q.dispatchEvent(new Event("input"));
  q.focus();
});

bootstrap();
